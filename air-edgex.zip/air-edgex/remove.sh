#!/bin/bash

# shellcheck source=/dev/null
source .env

network_type=${AIR_INSTALLER_NETWORK_TYPE:-online}
os_type=${AIR_INSTALLER_OS_TYPE:-linux}
arch_type=${AIR_INSTALLER_ARCH_TYPE:-amd64}

original_path=${PWD}

# Stop edge x and simulators
pushd "${original_path}/labs-air-edgex" > /dev/null || exit 1
./stop.sh "${network_type}" "${os_type}" "${arch_type}"
popd || exit 1

# Stop lightcrane
pushd "${original_path}/labs-lightcrane-services" > /dev/null || exit 1
./stop.sh "${network_type}" "${os_type}" "${arch_type}" "backend"
popd || exit 1

# Stop lightcrane agent
pushd "${original_path}/labs-lightcrane-services" > /dev/null || exit 1
./stop.sh "${network_type}" "${os_type}" "${arch_type}" "agent"
popd || exit 1

# Delete air infrastructure
pushd "${original_path}/labs-air-charts" > /dev/null || exit 1
./stop.sh "${network_type}" "${os_type}" "${arch_type}"
popd  || exit 1