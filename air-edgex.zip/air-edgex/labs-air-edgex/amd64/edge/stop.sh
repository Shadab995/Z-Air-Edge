#!/bin/bash

docker-compose -p edgex down -v
