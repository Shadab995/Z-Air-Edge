#!/bin/bash

# shellcheck source=/dev/null
source .env

network_type=${AIR_INSTALLER_NETWORK_TYPE:-online}
os_type=${AIR_INSTALLER_OS_TYPE:-linux}
arch_type=${AIR_INSTALLER_ARCH_TYPE:-amd64}

# Check dependencies
check_dependencies(){
    # Docker dependency
    if ! command -v docker &> /dev/null
    then
        echo "Docker could not be found and is required, please install it."
        exit
    fi
    # Docker compose dependency
    if ! command -v docker-compose &> /dev/null
    then
        echo "Docker Compose could not be found and is required, please install it."
        exit
    fi
}

install_component() {
    component_name=${1:?}
    case "${component_name}" in
    "air-backend")
        install_air_backend || exit 1
        ;;
    "lightcrane-backend")
        install_lightcrane_backend || exit 1
        ;;
    "lightcrane-agent")
        install_lightcrane_agent || exit 1
        ;;
    "edge")
        install_edge || exit 1
        ;;
    *)
        echo "Error, invalid component name ${component_name}, there are only 4 components to install: air-backend lightcrane-backend lightcrane-agent edge"
        exit 1
        ;;
esac
}

install_air_backend() {
    echo "Installing air backend"
    # Install air infrastructure
    pushd "./labs-air-charts" > /dev/null || exit 1
    ./start.sh "${network_type}" "${os_type}" "${arch_type}" || exit 2
    popd || exit 1
}

install_lightcrane_backend() {
    echo "Installing lightcrane backend"
    # Install lightcrane
    pushd "./labs-lightcrane-services" > /dev/null || exit 1
    ./start.sh "${network_type}" "${os_type}" "${arch_type}" "backend" || exit 2
    popd || exit 1
}

install_lightcrane_agent() {
    echo "Installing lightcrane backend"
    # Install lightcrane
    pushd "./labs-lightcrane-services" > /dev/null || exit 1
    ./start.sh "${network_type}" "${os_type}" "${arch_type}" "agent" || exit 2
    popd || exit 1
}

install_edge() {
    echo "Installing edge"
    # Install edgex and simulators
    pushd "./labs-air-edgex" > /dev/null || exit 1
    ./start.sh "${network_type}" "${os_type}" "${arch_type}" || exit 2
    popd || exit 1
}


check_dependencies

docker ps > /dev/null || (echo Docker must be running && exit 1)

case $# in
   0)
      echo "Installing all components"
      install_air_backend || exit 1
      install_lightcrane_backend || exit 1
      install_lightcrane_agent || exit 1
      install_edge || exit 1
      ;;
   1)
      install_component "$1" || exit 1
      ;;
   2)
      install_component "$1" || exit 1
      install_component "$2" || exit 1
      ;;
   3)
      install_component "$1" || exit 1
      install_component "$2" || exit 1
      install_component "$3" || exit 1
      ;;
   4)
      install_component "$1" || exit 1
      install_component "$2" || exit 1
      install_component "$3" || exit 1
      install_component "$4" || exit 1
      ;;
   *)
      echo "Error, there are only 4 components to install: air-backend lightcrane-backend lightcrane-agent edge"
      exit 1
      ;;
esac

