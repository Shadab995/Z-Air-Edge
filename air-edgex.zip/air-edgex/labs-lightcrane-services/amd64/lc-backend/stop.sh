export VERSION=0.7.0
export USER_HOME=~
export LC_HOME=./LC
export LC_EXT=$LC_HOME/runtimeGOPath
docker-compose down